//Matheus Almeida N00739768
//Alenric Apostol N01031550

package robotv.srp.robotv;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Manual extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);
    }
}
